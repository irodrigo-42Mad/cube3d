# **FT_PRINTF**
## **Re-writting Printf function from <stdio.h>** 
---
### In this project we have to re-write the functionality of OG printf with flags [-,0] and [s,c,d,i,u,x,X,p] conversors.
### You can use `make` to generate `ft_printf.a`
